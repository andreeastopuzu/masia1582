document.addEventListener('DOMContentLoaded', () => {
  const container = document.getElementById('calendar-container');
  if (!container) return;

  const MONTHS = ['January','February','March','April','May','June','July','August','September','October','November','December'];
  const DAYS = ['Mon','Tue','Wed','Thu','Fri','Sat','Sun'];

  let bookedDates = [];
  let currentMonth = new Date().getMonth();
  let currentYear = new Date().getFullYear();

  async function fetchCalendar() {
    try {
      const response = await fetch('/api/calendar');
      if (!response.ok) throw new Error('Failed to load');
      const icsText = await response.text();
      bookedDates = parseICS(icsText);
    } catch (e) {
      bookedDates = [];
    }
    render();
  }

  function parseICS(text) {
    const dates = [];
    const events = text.split('BEGIN:VEVENT');
    for (let i = 1; i < events.length; i++) {
      const startMatch = events[i].match(/DTSTART;?[^:]*:(\d{8})/);
      const endMatch = events[i].match(/DTEND;?[^:]*:(\d{8})/);
      if (startMatch && endMatch) {
        const start = parseDate(startMatch[1]);
        const end = parseDate(endMatch[1]);
        let d = new Date(start);
        while (d < end) {
          dates.push(d.toISOString().slice(0, 10));
          d.setDate(d.getDate() + 1);
        }
      }
    }
    return dates;
  }

  function parseDate(str) {
    return new Date(
      parseInt(str.slice(0, 4)),
      parseInt(str.slice(4, 6)) - 1,
      parseInt(str.slice(6, 8))
    );
  }

  function isBooked(year, month, day) {
    const dateStr = `${year}-${String(month + 1).padStart(2, '0')}-${String(day).padStart(2, '0')}`;
    return bookedDates.includes(dateStr);
  }

  function renderMonth(year, month) {
    const firstDay = new Date(year, month, 1).getDay();
    const startDay = firstDay === 0 ? 6 : firstDay - 1;
    const daysInMonth = new Date(year, month + 1, 0).getDate();

    let html = `<div class="calendar-month">`;
    html += `<div class="calendar-month__header">
      <h3 style="font-size: var(--text-xl);">${MONTHS[month]} ${year}</h3>
    </div>`;
    html += `<div class="calendar-grid-view">`;

    DAYS.forEach(d => {
      html += `<div class="calendar-day calendar-day--header">${d}</div>`;
    });

    for (let i = 0; i < startDay; i++) {
      html += `<div class="calendar-day"></div>`;
    }

    for (let day = 1; day <= daysInMonth; day++) {
      const booked = isBooked(year, month, day);
      const cls = booked ? 'calendar-day--booked' : 'calendar-day--available';
      html += `<div class="calendar-day ${cls}">${day}</div>`;
    }

    html += `</div></div>`;
    return html;
  }

  function render() {
    let html = `<div style="display: flex; align-items: center; justify-content: space-between; margin-bottom: var(--space-xl);">
      <button onclick="window.__calPrev()" class="btn btn--secondary" style="padding: 0.5rem 1rem;">&larr; Previous</button>
      <button onclick="window.__calNext()" class="btn btn--secondary" style="padding: 0.5rem 1rem;">Next &rarr;</button>
    </div>`;

    html += renderMonth(currentYear, currentMonth);

    const nextMonth = currentMonth === 11 ? 0 : currentMonth + 1;
    const nextYear = currentMonth === 11 ? currentYear + 1 : currentYear;
    html += renderMonth(nextYear, nextMonth);

    container.innerHTML = html;
  }

  window.__calPrev = () => {
    currentMonth--;
    if (currentMonth < 0) { currentMonth = 11; currentYear--; }
    render();
  };

  window.__calNext = () => {
    currentMonth++;
    if (currentMonth > 11) { currentMonth = 0; currentYear++; }
    render();
  };

  fetchCalendar();
});
