export async function onRequestGet(context) {
  // Replace with your actual Airbnb iCal URL
  const ICAL_URL = context.env.ICAL_URL || "https://www.airbnb.com/calendar/ical/688826624995880642.ics?s=YOUR_SECRET_KEY";

  try {
    const response = await fetch(ICAL_URL, {
      cf: { cacheTtl: 3600 }
    });

    if (!response.ok) {
      return new Response('Calendar unavailable', { status: 502 });
    }

    const icsText = await response.text();

    return new Response(icsText, {
      headers: {
        'Content-Type': 'text/calendar',
        'Access-Control-Allow-Origin': 'https://masiastsalvador1582.com',
        'Cache-Control': 'public, max-age=3600'
      }
    });
  } catch (error) {
    return new Response('Calendar service error', { status: 500 });
  }
}
